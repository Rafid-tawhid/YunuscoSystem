import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:yunusco_group/providers/product_provider.dart';
import 'package:yunusco_group/utils/colors.dart';
import 'package:yunusco_group/utils/constants.dart';

import '../../models/purchase_order_model.dart';



class PurchaseOrdersListScreen extends StatefulWidget {
  final List<PurchaseOrderModel> purchaseOrders;

  const PurchaseOrdersListScreen({Key? key, required this.purchaseOrders}) : super(key: key);

  @override
  _PurchaseOrdersListScreenState createState() => _PurchaseOrdersListScreenState();
}

class _PurchaseOrdersListScreenState extends State<PurchaseOrdersListScreen> {
  // Filtering variables
  String _searchQuery = '';
  String _filterStatus = 'All';
  String _filterType = 'All';

  @override
  void initState() {
   // getPurchaseInfo();
    super.initState();
  }
  void getPurchaseInfo() {
    var pp=context.read<ProductProvider>();
    //pp.getAllPurchaseList();
  }

  @override
  Widget build(BuildContext context) {
    // Filter purchase orders based on search and filter criteria
    final filteredOrders = widget.purchaseOrders.where((order) {
      final matchesSearch = _searchQuery.isEmpty ||
          order.purchaseOrderCode!.toLowerCase().contains(_searchQuery.toLowerCase()) ||
          order.supplierName!.toLowerCase().contains(_searchQuery.toLowerCase());

      final matchesStatus = _filterStatus == 'All' ||
          (_filterStatus == 'Confirmed' && order.isConfirmed == true) ||
          (_filterStatus == 'Pending' && order.isConfirmed != true);

      final matchesType = _filterType == 'All' || order.orderType == _filterType;

      return matchesSearch && matchesStatus && matchesType;
    }).toList();

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Purchase Orders'),
        backgroundColor: myColors.primaryColor,
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: _showFilterDialog,
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'Search by code or supplier...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                filled: true,
                fillColor: Colors.grey.shade100,
              ),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value;
                });
              },
            ),
          ),
          // Results count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${filteredOrders.length} orders found',
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 14,
                  ),
                ),
                if (_filterStatus != 'All' || _filterType != 'All')
                  InkWell(
                    onTap: () {
                      setState(() {
                        _filterStatus = 'All';
                        _filterType = 'All';
                      });
                    },
                    child: Text(
                      'Clear filters',
                      style: TextStyle(
                        color: Colors.blue.shade700,
                        fontSize: 14,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          // Purchase orders list
          Expanded(
            child: filteredOrders.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
              itemCount: filteredOrders.length,
              itemBuilder: (context, index) {
                return _buildOrderCard(filteredOrders[index]);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderCard(PurchaseOrderModel order) {
    return Card(
      color: Colors.white,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        onTap: () {
          // Handle order tap (view details)
          _showOrderDetails(order);
        },
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header row with order code and status
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    order.purchaseOrderCode ?? 'N/A',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: order.isConfirmed == true ? Colors.green.shade100 : Colors.orange.shade100,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      order.isConfirmed == true ? 'Confirmed' : 'Pending',
                      style: TextStyle(
                        color: order.isConfirmed == true ? Colors.green.shade800 : Colors.orange.shade800,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Order details
              _buildDetailRow('Supplier', order.supplierName ?? 'N/A'),
              const SizedBox(height: 8),
              _buildDetailRow('Order Date', _formatDate(order.orderDate)),
              const SizedBox(height: 8),
              _buildDetailRow('Type', '${order.orderType} • ${order.purchaseType}'),
              const SizedBox(height: 8),
              if (order.approve != null) _buildDetailRow('Approver', order.approve!),
              if (order.remarks != null && order.remarks!.isNotEmpty) ...[
                const SizedBox(height: 8),
                _buildDetailRow('Remarks', order.remarks!),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 80,
          child: Text(
            label,
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 14,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 14,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.inventory_2_outlined,
            size: 64,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 16),
          Text(
            'No purchase orders found',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Try adjusting your search or filters',
            style: TextStyle(
              color: Colors.grey.shade500,
            ),
          ),
        ],
      ),
    );
  }

  void _showFilterDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              title: const Text('Filter Orders'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Status',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    children: [
                      FilterChip(
                        label: const Text('All'),
                        selected: _filterStatus == 'All',
                        onSelected: (selected) {
                          setState(() {
                            _filterStatus = 'All';
                          });
                        },
                      ),
                      FilterChip(
                        label: const Text('Confirmed'),
                        selected: _filterStatus == 'Confirmed',
                        onSelected: (selected) {
                          setState(() {
                            _filterStatus = 'Confirmed';
                          });
                        },
                      ),
                      FilterChip(
                        label: const Text('Pending'),
                        selected: _filterStatus == 'Pending',
                        onSelected: (selected) {
                          setState(() {
                            _filterStatus = 'Pending';
                          });
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Order Type',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  // This would ideally be populated with actual types from your data
                  Wrap(
                    spacing: 8,
                    children: [
                      FilterChip(
                        label: const Text('All'),
                        selected: _filterType == 'All',
                        onSelected: (selected) {
                          setState(() {
                            _filterType = 'All';
                          });
                        },
                      ),
                      FilterChip(
                        label: const Text('Type 1'),
                        selected: _filterType == 'Type 1',
                        onSelected: (selected) {
                          setState(() {
                            _filterType = 'Type 1';
                          });
                        },
                      ),
                      FilterChip(
                        label: const Text('Type 2'),
                        selected: _filterType == 'Type 2',
                        onSelected: (selected) {
                          setState(() {
                            _filterType = 'Type 2';
                          });
                        },
                      ),
                    ],
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    // State is already updated via the setState callback
                  },
                  child: const Text('Apply'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showOrderDetails(PurchaseOrderModel order) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      builder: (context) {
        return DraggableScrollableSheet(
          expand: false,
          maxChildSize: 0.9,
          initialChildSize: 0.7,
          builder: (context, scrollController) {
            return SingleChildScrollView(
              controller: scrollController,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 16),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade300,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          order.purchaseOrderCode ?? 'N/A',
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          decoration: BoxDecoration(
                            color: order.isConfirmed == true ? Colors.green.shade100 : Colors.orange.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            order.isConfirmed == true ? 'Confirmed' : 'Pending',
                            style: TextStyle(
                              color: order.isConfirmed == true ? Colors.green.shade800 : Colors.orange.shade800,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'Order Details',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),
                    _buildDetailItem('Supplier', order.supplierName ?? 'N/A'),
                    _buildDetailItem('Order Date', _formatDate(order.orderDate)),
                    _buildDetailItem('Order Type', order.orderType ?? 'N/A'),
                    _buildDetailItem('Purchase Type', order.purchaseType ?? 'N/A'),
                    if (order.approvalFieldCode != null) _buildDetailItem('Approval Code', order.approvalFieldCode.toString()),
                    if (order.approve != null) _buildDetailItem('Approver', order.approve!),
                    if (order.remarks != null && order.remarks!.isNotEmpty) _buildDetailItem('Remarks', order.remarks!),
                    const SizedBox(height: 24),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () {
                          // Handle action button
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: myColors.primaryColor,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child:  Text('View Full Details',style: customTextStyle(18, Colors.white, FontWeight.normal),),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildDetailItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 14,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          const Divider(height: 1),
        ],
      ),
    );
  }

  String _formatDate(String? dateString) {
    if (dateString == null || dateString.isEmpty) return 'N/A';

    try {
      final DateTime date = DateTime.parse(dateString);
      return '${date.day}/${date.month}/${date.year}';
    } catch (e) {
      return dateString;
    }
  }
}


