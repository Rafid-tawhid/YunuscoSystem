import 'dart:async';
import 'dart:io' show Platform;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:provider/provider.dart';
import 'package:yunusco_group/helper_class/dashboard_helpers.dart';
import 'package:yunusco_group/providers/notofication_provider.dart';
import 'package:yunusco_group/screens/Inventory/inventory_dashboard.dart';
import 'package:yunusco_group/screens/notification_screen.dart';
import 'package:yunusco_group/providers/auth_provider.dart';
import 'package:yunusco_group/service_class/notofication_helper.dart';
import 'package:yunusco_group/utils/colors.dart';
import 'package:yunusco_group/utils/constants.dart';
import '../common_widgets/drawer.dart';
import '../providers/auth_provider.dart';
import '../providers/hr_provider.dart';
import 'Purchasing/purchase_requisation_list.dart';
import 'Accounts/account_menu_screen.dart';
import 'HR&PayRoll/doc_appointment_requisation.dart';
import 'HR&PayRoll/hr_main_screen.dart';
import 'HR&PayRoll/widgets/doctor_appointment_list_screen.dart';
import 'Import/master_lc_list_screen.dart';
import 'Management/management_dashboard.dart';
import 'Planning/planning_screen.dart';
import 'Products/product_home_screen.dart';
import 'Purchasing/purchasing_dashboard.dart';
import 'Report/report_screen.dart';
import 'login_screen.dart';
import 'Merchandising/merchandisingDashboardcreen.dart';

class HomeScreen extends StatefulWidget {
  final String? buttonLabel;
  final bool? isOnTp;
  const HomeScreen({super.key, this.buttonLabel, this.isOnTp});
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int myIndex = 0;
  final ScrollController _scrollController = ScrollController();
  bool _showLogo = false;
  double _scrollPosition = 0; // List<Menu> menus = [];
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
      FlutterLocalNotificationsPlugin();
  @override
  void initState() {
    super.initState();
    _getModules();
    if (Platform.isAndroid) {
      NotificationServices.setupPushNotifications(context);
      NotificationServices.initializeNotifications();
    }
    _scrollController.addListener(() {
      setState(() {
        _scrollPosition = _scrollController.position.pixels;
        _showLogo = _scrollPosition >
            50; // Adjust this value for when the logo should appear
      });
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _getModules() async {
    var ap = context.read<AuthProvider>();
    ap.getMenuList();
    AppConstants.token = await DashboardHelpers.getString('token');
    DashboardHelpers.currentUser = await DashboardHelpers.getUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MyDrawer(),
      appBar: AppBar(
        backgroundColor: Color(0xFF000044),
        centerTitle: true,
        title: AnimatedCrossFade(
          duration: Duration(milliseconds: 300),
          crossFadeState:
              _showLogo ? CrossFadeState.showSecond : CrossFadeState.showFirst,
          firstChild: Text(
            'Welcome',
            style: customTextStyle(20, Colors.white, FontWeight.w600),
          ),
          secondChild: Image.asset(
            'assets/images/icon.png',
            height: 40,
          ),
        ),
        iconTheme: IconThemeData(
          color: Colors.white,
        ),
        actions: [
          InkWell(
            onTap: () {
              Navigator.push(
                  context,
                  CupertinoPageRoute(
                      builder: (context) => NotificationsScreen()));
            },
            child: Stack(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Icon(Icons.notifications_active),
                ),
                Positioned(
                  top: 0,
                  right: 0,
                  child: Consumer<NotificationProvider>(
                    builder: (context, pro, _) => Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          color: Colors.red, shape: BoxShape.circle),
                      child: Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Text(
                          pro.notificationCount.toString(),
                          style:
                              customTextStyle(8, Colors.white, FontWeight.w500),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          IconButton(
              onPressed: () async {
                bool? isLogout =
                    await DashboardHelpers.showLogoutDialog(context);
                if (isLogout == true) {
                  await context.read<AuthProvider>().logout();
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => LoginScreen()));
                }
              },
              icon: Icon(
                Icons.logout,
                color: Colors.white,
              ))
        ],
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          color: myColors.primaryColor,
          image: DecorationImage(
            image: AssetImage('assets/images/nbn2-min.png'),
            fit: BoxFit.fill,
          ),
        ),
        child: SingleChildScrollView(
          controller: _scrollController,
          child: Column(
            children: [
              Image.asset(
                'assets/images/icon.png',
                height: 120,
                width: 200,
              ),
              Consumer<AuthProvider>(
                builder: (context, pro, _) => GridView.builder(
                  padding: const EdgeInsets.all(10.0),
                  itemCount: pro.menuList.length,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2),
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        setState(() {
                          myIndex = index;
                        });
                        _navigateToScreen(pro.menuList[index].id);
                      },
                      child: Card(
                        color: Colors.white,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(pro.menuList[index].icon, height: 70),
                            SizedBox(
                              height: 8,
                            ),
                            Text(
                              pro.menuList[index].title,
                              style: AppConstants.customTextStyle(
                                  16, Colors.black, FontWeight.w500),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _navigateToScreen(int menuId) async {
    debugPrint('menuId $menuId');
    switch (menuId) {
      case 6:
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => MerchandisingScreen()));
        break;
      case 7: // Navigator.push(context, CupertinoPageRoute(builder: (context) => PurchaseApprovalScreen()));
        Navigator.push(
            context,
            CupertinoPageRoute(
                builder: (context) => PurchasingDashboard()));
        break;
      case 44:
        Navigator.push(
            context,
            CupertinoPageRoute(
                builder: (context) => ManagementDashboardScreen()));
        break;
      case 8:
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => PlanningScreen()));
        break;
      case 45:
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => ProductHomeScreen()));
        break;
      case 13:
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => InventoryHomeScreen()));
        break;
      case 1:
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => HrMainMenuScreen()));
      case 14:
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => MasterLCListScreen()));
      case 4: //Navigator.push(context, CupertinoPageRoute(builder: (context) => PfListScreen()));
        Navigator.push(context,
            CupertinoPageRoute(builder: (context) => AccountMenuScreen()));
        break;
      case 46:
        Navigator.push(
            context,
            CupertinoPageRoute(
                builder: (context) => ProductionStrengthScreen()));
      case 52:
        var hp = context.read<HrProvider>();
        await hp
            .getAllDocAppointment(); //go to different screen depending on designation
        if (DashboardHelpers.currentUser!.designation == 'Medical Officer') {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => AppointmentListScreen()));
        } else {
          Navigator.push(context,
              CupertinoPageRoute(builder: (context) => DocAppoinmentReq()));
        }
        break;
      default:
        DashboardHelpers.showAlert(msg: 'Not Available');
        return;
    }
  }
}

class Menu {
  final int id;
  final String icon;
  final String title;
  bool isVisible;
  Menu(this.id, this.icon, this.title, this.isVisible);
}
